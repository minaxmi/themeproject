<?php
/**
 * Wander functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Wander
 */
function wander_child_scripts() {
    wp_enqueue_style( 'wander-parent-style', get_template_directory_uri(). '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'wander_child_scripts' );